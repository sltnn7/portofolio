<?php

namespace App\Controllers;

use App\Models\ContactModel;
use CodeIgniter\Controller;

class Contact extends Controller
{
    public function submit()
    {
        $contactModel = new ContactModel();

        $data = [
            'name'    => $this->request->getPost('name'),
            'phone'   => $this->request->getPost('phone'),
            'email'   => $this->request->getPost('email'),
            'subject' => $this->request->getPost('subject'),
            'message' => $this->request->getPost('message'),
        ];

        if ($contactModel->insert($data)) {
            return redirect()->to('/home')->with('status', 'Data successfully inserted!');
        } else {
            return redirect()->to('/home')->with('status', 'Failed to insert data.');
        }
    }
}
