<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// Tambahkan route untuk menangani pengiriman form kontak
$routes->post('contact/submit', 'Contact::submit');

$routes->get('contact', 'Contact::index');
